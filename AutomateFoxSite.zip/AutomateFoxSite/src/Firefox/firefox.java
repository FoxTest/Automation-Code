/**
 * 
 */
package Firefox;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * @author Abhilash
 *
 */
public class firefox {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:/Users/abhilash/Downloads/chromedriver_win32/chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.fox.com/");		
		
		
		/** -- below code is used to create a Fox account
		driver.findElement(By.cssSelector("#path-1")).click();
		WebDriverWait da = new WebDriverWait(driver, 10);
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/div[4]/button[1]")).click(); 
		System.out.println(driver.getTitle());
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[4]/div[1]/input")).sendKeys("Fox");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/input")).sendKeys("Test");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[6]/input")).sendKeys("Fox.Test@gmail.com");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[8]/div/input")).sendKeys("Fox123456");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[10]/div[1]/div/div/div")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[10]/div[1]/div/div[2]/a[1]/div")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[10]/div[2]/input")).sendKeys("06/23/1983");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[13]/button")).click();
		*/
		
		
		/** below code use to sign In to the account
		driver.findElement(By.cssSelector("#path-1")).click();
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div/div[4]/button[2]")).click(); 
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[4]/input")).sendKeys("Fox.Test@gmail.com");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[4]/div[2]/input")).sendKeys("Fox123456");
		driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[2]/div[1]/div[2]/div[4]/div[6]/button")).click();
		*/
		

		
		
		
		
		
		
		
		
				
		
	}
	

}
